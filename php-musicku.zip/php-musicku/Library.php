<div class="bgimg">
  <div class="topleft">
    <p>Logo</p>
  </div>
  <div class="middle">
    <h1>COMING SOON</h1>
    <hr>
    <p>35 days</p>
  </div>
  <div class="bottomleft">
    <p>Some text</p>
  </div>
</div>